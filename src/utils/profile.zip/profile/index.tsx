import { updateuserType } from "@/types";
import { adyashaphoto } from "@/assets/profile";
export const updateuser: updateuserType[] = [
  {
    id: 1,
    firstName: "adyasha",
    middleName: "",
    lastName: "biswal",
    username: "somya",
    img: adyashaphoto,
    email: "adya@1234gmail.com",
    phoneNumber: 9938795482,
    address: "rasulgad",
    password: 123456,
    registrationType: "user",
    aadharNumber: 902837339282,
    area: "odisha",
    city: "cuttack",
    state: "odisha",
    language: "odia",
  },
];
