import axios from "axios";
import { connectToServerLink } from "@/constants";

const setHttpHeaders = () => {
  axios.defaults.headers = {
    Accept: "application/json",
    "Content-Type": "application/json",
  };
};
export default function intializeAxios() {
  axios.defaults.baseURL = connectToServerLink;
  setHttpHeaders();
}
