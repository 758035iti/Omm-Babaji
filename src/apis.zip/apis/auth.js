import axios from "axios";
const register = (user) => axios.post("/register", user);
const login = (user) => axios.post("/login", user);
const authApi = { register };
export default authApi;
