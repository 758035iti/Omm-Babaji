import Booking_process from "@/components/booking_process/Booking_process";
export default function page() {
  return (
    <>
      <Booking_process />
    </>
  );
}
