import Profile from "@/components/profile/Profile";
export default function page() {
  return (
    <>
      <Profile />
    </>
  );
}
