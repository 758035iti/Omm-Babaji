export { default as process1 } from "./process1.webp";
export { default as process2 } from "./process2.webp";
export { default as process3 } from "./process3.webp";
export { default as process4 } from "./process4.webp";
export { default as process5 } from "./process5.webp";
