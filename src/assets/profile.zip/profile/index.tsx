export { default as adyashaphoto } from "./adyashaphoto.jpg";
